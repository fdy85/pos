<?php

namespace App\Http\Livewire\Admin\Folios;

use App\Models\Award;
use App\Models\Client;
use App\Models\Cost;
use App\Models\Folio;
use App\Models\Item;
use App\Models\Material;
use App\Models\Slogan;
use App\Models\Weight;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\View\Components\Alert;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use Livewire\WithPagination;

class FoliosIndex extends Component
{
    use WithPagination;

    public $subTitle = 'Listado', $modalTitle = 'FOLIOS', $selectedId = 0, $currentFolio,
            $allFolios, 
            $folioType, $client_id, $material_id, $item_id, $qty, $cost, $total, $info= [], $weights = [], 
            $tempItemId, $tempItemName, $tempClientName, $newFolioTotalCost, $slogan,
            $search, $formOpen, $formOpenDetails, $printTicketWindow;

    /* GET Parameter from URL if exists */
    protected $queryString = ['selectedId'];

    public function mount(){
        $this->allFolios = false;
        $this->search = '';
        $this->formOpen = false;
        $this->formOpenDetails = false;
        $this->printTicketWindow = false;
    /* If Selected ID exist as parameter in GET Route */
        if($this->selectedId > 0){
        /* Call Form to show Folio */
            $this->details(Folio::find($this->selectedId));
        }
    }

    public function updatingSearch(){
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy'];
    
    public function render()
    {
        //Query without BoxcutId
        $currentUser = auth()->user();
        switch($this->allFolios){
        /* Query specific Branch's folios */
            case false:
                $folios = Folio::whereHas('client', function ($q){
                    $q->where('clients.name', 'like', '%'.$this->search.'%')
                    ->orWhere('folios.id', 'like', '%'.$this->search.'%');
                })->with('branch_office')
                ->where('folios.status', true)
                ->where('branch_office_id', $currentUser->branch_office_id)
                ->orderBy('folios.id', 'desc')
                ->paginate(50);
            break;

            case true:
        /* Query All Folios */
                $folios = Folio::whereHas('client', function ($q){
                    $q->where('clients.name', 'like', '%'.$this->search.'%')
                    ->orWhere('folios.id', 'like', '%'.$this->search.'%');
                })->with('branch_office')
                ->where('folios.status', true)
                ->orderBy('folios.id', 'desc')
                ->paginate(50);
            break;
        }
        $clients = Client::where('status', true)->get();
        $materials = Material::where('status', true)->get();
        $saleItems = Item::where('status', true)->get();
          
        return view('livewire.admin.folios.folios-index', [
                                                            'items' => $folios,
                                                            'clients' => $clients,
                                                            'materials' => $materials,
                                                            'saleItems' => $saleItems
                                                        ]); 
    }

    /* show-form */
    public function showForm(){
    /* Reset params */
        $this->resetUI();
    /* Set params */
        $this->folioType = 'Compra';
        $this->formOpen = true;
    }

    /* show-details */
    public function details(Folio $folio){
    /* Reset params */
        $this->resetUI();
    /* Set params */
        $this->currentFolio = $folio;
    /* Show Form */
        $this->formOpenDetails = true;
    }

    /* Call Prev Folio */
    public function previousFolio(Folio $folio){
    /* Infinite Loop */
        $previous = Folio::where('id', '<', $folio->id)->max('id');
        $this->currentFolio = Folio::find($previous);
        if($this->currentFolio){
            if($this->currentFolio->branch_office->id != auth()->user()->branch_office->id){
                $this->previousFolio($this->currentFolio);
            }
        }else{
            $this->currentFolio = Folio::latest()->first();
        }
        
    }
    /* Call Next Folio */
    public function nextFolio(Folio $folio){
    /* Infinite Loop */
        $next = Folio::where('id', '>', $folio->id)->min('id');
        $this->currentFolio = Folio::find($next);
        if($this->currentFolio){
            if($this->currentFolio->branch_office->id != auth()->user()->branch_office->id){
                $this->nextFolio($this->currentFolio);
            }
        }else{
            $this->currentFolio = Folio::first();
        }
    }

    /* print Ticket */
    public function printTicket(Folio $folio){
    /* Route that will print the Ticket */
        return redirect()->to('admin/folios/print-ticket?selectedId='.$folio->id);
    }

    /* get the Material/Item Cost */
    /* For SIMULATION */
    public function getCost(){
        if($this->client_id > 0 ){
            if($this->material_id != NULL || $this->item_id != NULL){
                switch($this->folioType){
                    case 'Compra':
                    /* Get Cost */
                        $costPG = Cost::where('client_id', 1)
                                    ->where('costable_id', $this->material_id)
                                    ->where('costable_type', Material::class)
                                    ->first();
                        
                        $cost = Cost::where('client_id', $this->client_id)
                                        ->where('costable_id', $this->material_id)
                                        ->where('costable_type', Material::class)
                                        ->first();
                    /* Get Material Name */
                        $this->tempItemName = Material::find($this->material_id);
                        
                    break;
                    case 'Venta':
                        /* Get Cost */
                        $costPG = Cost::where('client_id', 1)
                                    ->where('costable_id', $this->item_id)
                                    ->where('costable_type', Item::class)
                                    ->first();
        
                        $cost = Cost::where('client_id', $this->client_id)
                                        ->where('costable_id', $this->item_id)
                                        ->where('costable_type', Item::class)
                                        ->first();
                    /* Get Item Name */
                        $this->tempItemName = Item::find($this->item_id);
                    break;
                }
            /* Get Info */
                $this->tempItemId = $this->tempItemName->id;
                $this->tempClientName = Client::find($this->client_id)->name;
            /* Set cost by Client Selected */
                if($cost){
                    $this->cost = $cost->cost;
                }else{
                    $this->cost = $costPG->cost;
                }
            /* Get Total */
                $this->total = $this->qty * $this->cost;
            }else{
            /* VALIDATION */
            /* Error Toast && reset Qty param*/  
                $this->reset(['qty']);
                $this->emit('toast-message', ['msg' => 'Se necesita la información del Material ó Artículo de Venta', 'icon' =>'error']);
            }
        }else{
        /* VALIDATION */
        /* Error Toast && reset Qty param*/  
            $this->reset(['qty']);
            $this->emit('toast-message', ['msg' => 'Se necesita la información del Cliente', 'icon' =>'error']);
        }
    }

    /* Simulation */
    public function addWeight(){
    /* Start to simulate New Folio */
        if(count($this->info) == 0){
        /* Set grl Info  */
            array_push($this->info, ['folio_type' => $this->folioType, 
                                        'client_name' => $this->tempClientName
                                    ]); 
        }
    /* Add New weights to Array */
        array_push($this->weights, ['item' => $this->tempItemName->name, 
                                    'item_id' => $this->tempItemId,
                                    'weight' => $this->qty, 
                                    'cost' => $this->cost,
                                    'total' => $this->total
                                    ]);
    /* Get new Total */
        $this->newFolioTotalCost += $this->total;
    /* Reset Params */
        $this->reset(['qty', 'cost', 'total','tempItemName']);
    }

    /* Generate Simulation Folio */
    public function addFolio(){
        /* RULES */
        $rules = ['client_id' => 'required'];
        $messages = ['client_id.required' => 'El Cliente es Requerido'];
    /* Specific Rules */
        if($this->folioType == 'Compra'){
            $rules += array('material_id' => 'required');
            $messages += array('material_id.required' => 'El Material es Requerido');
        }else{
            $rules += array('item_id' => 'required');
            $messages += array('item_id.required' => 'El Artículo de Venta es Requerido');
        }
        $this->validate($rules, $messages);
    /* New Folio */
    //status => 1   Terminado
        $newFolio = Folio::create(['total_cost' => $this->newFolioTotalCost, 'capture_type' => 'Manual', 'status' => 1,
                                    'folio_type' => $this->folioType, 'client_id' =>$this->client_id,
                                    'branch_office_id' => auth()->user()->branch_office_id, 'user_id' => Auth()->id()]);
    /* New Weights */
        foreach($this->weights as $weight){
            if($this->folioType == 'Compra'){
            //Folios from web platform
                Weight::create(['weight' => $weight['weight'],
                                'cost' => $weight['cost'],
                                'capture_type' => 'Manual',
                                'status' => 1, //Completado
                                'material_id' => $weight['item_id'],
                                'client_id' => $this->client_id,
                                'folio_id' => $newFolio->id,
                                'user_id' => Auth()->id()
                                ]);    
            /* AWARDS */
            //Do not registered awards for client #1 [Público en Gral]
            /* Get current increasing award */
                $award = collect();
                if($newFolio->client_id != 1){
                    $award = Award::where('material_id', $weight['item_id'])
                                ->where('client_id', intval($this->client_id))
                                ->limit(1)
                                ->get();
                }
            //AWARDS
            /* If Award exists still incrementing record */
            /* Award's Top = 5 Toneladas */
                if($award->count()){
                    $tw = $award[0]->total_weight;
                /* Set status to winner if overcomes Top */
                    $award[0]->total_weight + $weight['weight'] >= 5000 
                        ? $award[0]->update(['total_weight' => $tw + $weight['weight'], 'status' => true]) 
                        : $award[0]->update(['total_weight' => $tw + $weight['weight']]);
                }else{
                //Do not registered awards for client #1 [úblico en Gral]
                    if($newFolio->client_id != 1){
                    /* New Award record */
                        $award = Award::create(['total_weight' => $weight['weight'], 
                                        'client_id' => $this->client_id,
                                        'material_id' => $weight['item_id']]);
                    }
                }
            }else{
            //new WEIGHT
            //Para Material e Item solo existe la variable $material_id
                Weight::create(['weight' => $weight['weight'],
                                'cost' => $weight['cost'],
                                'capture_type' => 'Manual',
                                'status' => 1,
                                'item_id' => $weight['item_id'],
                                'client_id' => $this->client_id,
                                'folio_id' => $newFolio->id,
                                'user_id' => Auth()->id()
                                ]);
            }
        }
        $this->emit('toast-message', ['msg' => 'Folio '.$newFolio->id.' Registrado', 'icon' =>'success']);
        $this->formOpen = false;
    }

    /* delete record [listener] */
    public function destroy(Folio $folio){
        /* VALIDATE later */
        if($folio->users->count()){
            $this->emit('toast-message', ['msg' => 'La empresea tiene proyectos adjuntos. No puede ser eliminada', 'icon' =>'warning']);
        }else{
            try{
                $folio->delete($this->selectedId);
                //$this->resetPage();
                $this->emit('toast-message', ['msg' => 'Empresa Eliminada', 'icon' =>'success']);
                
            } catch (Exception $ex) {
                $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
            } 
        
        $this->resetUI();
        return redirect()->route('admin.folios.index');
        }
    }

    public function resetUI(){
        $this->reset(['selectedId', 
                    'allFolios', 
                    'folioType', 'client_id', 'material_id', 'item_id', 'qty', 'cost', 'total', 'info', 'weights', 
                    'tempItemId', 'tempItemName', 'tempClientName', 'newFolioTotalCost', 'slogan',
                    'formOpen', 'formOpenDetails', 'printTicketWindow', 'search']);
    }
}
