<?php

namespace App\Http\Livewire\Admin\Folios;

use App\Models\Folio;
use App\Models\Slogan;
use Livewire\Component;

class PrintTicket extends Component
{
    public $subTitle = 'Listado', $modalTitle = 'FOLIOS', $selectedId, $currentFolio, $slogan;

    /* GET Parameter from URL if exists */
    protected $queryString = ['selectedId'];

    public function mount(){
        $this->currentFolio = Folio::find($this->selectedId);
    }

    public function render()
    {
        $this->slogan = Slogan::all()->random()->first();
        return view('livewire.admin.folios.print-ticket', ['currentFolio' => $this->currentFolio,
                                                            'slogan' => $this->slogan
                                                        ]);
    }

}
