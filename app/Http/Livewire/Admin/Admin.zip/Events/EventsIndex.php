<?php

namespace App\Http\Livewire\Admin\Events;

use App\Models\Client;
use App\Models\Event;
use App\Models\Item;
use App\Models\Material;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class EventsIndex extends Component
{
    /* public params */
    public $subTitle = 'Eventos', $modalTitle = 'CALENDARIO', $selectedId, $eventInfo,
            $color, $titleId, $clientId, $titleNote, $materialId, $paymentMethod,
            $saleItemId, $weight, $address, $description, $start, $hourId, $status,
            $formEventOpen;

    public function mount(){
        $this->formEventOpen = false;
        $this->status = '';
        $this->selectedId = 0;
    }

    /* Listeners */
    protected $listeners = ['newEvent', 'getEventInfo'];

    public function render()
    {
        $clients = Client::where('status', true)->get();
        $materials = Material::where('status', true)->get();
        $saleItems = Item::where('status', true)->get();
        $hours = DB::table('hours')->pluck('hour', 'id');

        return view('livewire.admin.events.events-index',[
                                                        'clients' => $clients,
                                                        'materials' => $materials,
                                                        'saleItems' => $saleItems,
                                                        'hours' => $hours,
        ]);
    }

    /* show Form */
    public function newEvent($date){
    /* reset params */
        $this->resetUI();
    /* Set params */
        $this->paymentMethod = 'Efectivo';
        $this->start = $date;
    /* show Form */
        $this->formEventOpen = true;
    }

    /* Set params to default */
    public function defaultValues(){
        switch($this->titleId){
            case 'Recolectar':
                $this->titleNote = '';
                $this->saleItemId = null;
            break;
            case 'Entregar':
                $this->titleNote = '';
                $this->materialId = null;
            break;
            case 'Nota':
                $this->saleItemId = null;
                $this->materialId = null;
            break;
        }
    }

    /* Store Event */
    public function store(){
    /* new Event for NOTAS */
        /* RULES by Title */
        $rules = [];
        $messages = [];
        if($this->titleId == 'Nota'){
            $this->color = 'pink';
            $rules = ['titleNote' => 'required',
                    'description' => 'required',
                    'start' => 'required',
                    ];
            $messages = ['titleNote.required' => 'El Título de la Nota es requerido',
                        'description.required' => 'La descripción de la Nota es requerida',
                        'start.required' => 'La fecha de la Nota es requerida',
                        ];
        }else{
            $this->color = 'green';
            if($this->titleId == 'Recolectar'){
            /* Recolección */
                $rules = ['clientId' => 'required',
                        'materialId' => 'required',
                        'start' => 'required',
                        'hourId' => 'required',
                        ];
                $messages = ['clientId.required' => 'El Cliente para la Recolección es requerido',
                        'materialId.required' => 'El material es requerido',
                        'start.required' => 'La fecha de la Recolección es requerida',
                        'hour.required' => 'La hora de la Recolección es requerida',
                        ];
            }
            if($this->titleId == 'Entregar'){
            /* Entrega */
                $this->color = 'orange';
                $rules = ['clientId' => 'required',
                        'saleItemId' => 'required',
                        'start' => 'required',
                        'hourId' => 'required',
                        ];
                $messages = ['clientId.required' => 'El Cliente para la Entrega es requerido',
                        'saleItemId.required' => 'El artículo es requerido',
                        'start.required' => 'La fecha de la Recolección es requerida',
                        'hour.required' => 'La hora de la Recolección es requerida',
                        ];
            }
        }
        $this->validate($rules, $messages);
        //since table accepts null fields we can create record only once
        /* create record */
        try{
        /* Create Event */
            Event::create(['title' => $this->titleId,
                            'title_note' => $this->titleNote,
                            'desc' => $this->description,
                            'start' => $this->start,
                            'status' => 'Agendado',
                            'color' => $this->color,
                            'payment_method' => $this->paymentMethod,
                            'is_admin_approved' => true,
                            'hour_id' => $this->hourId,
                            'client_id' => $this->clientId,
                            'material_id' => $this->materialId,
                            'item_id' => $this->saleItemId,
                            'weight' => $this->weight,
                            'user_id' => Auth::id(),
                            'branch_office_id' => auth()->user()->branch_office_id,
                            ]);
            //REFETCH CALENDAR EVENTS AND TOAST
            $this->emit('toast-message', ['msg' => 'Evento registrado!', 'icon' =>'success']);
            $this->dispatchBrowserEvent('refetch-events', ['msg' => 'refetch']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* Get event Info at Clicking event */
    public function getEventInfo($eventInfo){
    /* Reset params */
        $this->resetUI();
    /* set params from Array*/
        $this->selectedId = $eventInfo['id'];
        $this->titleId = $eventInfo['extendedProps']['originalTitle'];
        $this->description = $eventInfo['extendedProps']['desc']; 
        $this->start = $eventInfo['start']; 
        $this->hourId = $eventInfo['extendedProps']['hour_id']; 
        $this->status = $eventInfo['extendedProps']['status'];
        $this->paymentMethod = $eventInfo['extendedProps']['payment_method'];
    /* set params by Event Title */
        if($this->titleId == 'Nota'){
            $this->titleNote = $eventInfo['extendedProps']['title_note'];
        }else{
            $this->clientId = $eventInfo['extendedProps']['client_id'];
            if($this->titleId == 'Recolectar'){
                $this->materialId = $eventInfo['extendedProps']['material_id']; 
                $this->weight = $eventInfo['extendedProps']['weight'];  
            }
            if($this->titleId == 'Entregar'){
                $this->saleItemId = $eventInfo['extendedProps']['item_id']; 
            }
        }
        $this->formEventOpen = true;
    }

    /* Update Evewnt */
    public function update(){
    /* RULES by Title */
        if($this->titleId == 'Nota'){
        /* Notas */
            $this->color = 'pink';
            $rules = ['titleNote' => 'required',
                    'description' => 'required',
                    'start' => 'required',
                    ];
            $messages = ['titleNote.required' => 'El Título de la Nota es requerido',
                        'description.required' => 'La descripción de la Nota es requerida',
                        'start.required' => 'La fecha de la Nota es requerida',
                        ];
        }else{
            $this->color = 'green';
            if($this->titleId == 'Recolectar'){
            /* Recolección */
                $rules = ['clientId' => 'required',
                        'materialId' => 'required',
                        'start' => 'required',
                        'hourId' => 'required',
                        ];
                $messages = ['clientId.required' => 'El Cliente para la Recolección es requerido',
                        'materialId.required' => 'El material es requerido',
                        'start.required' => 'La fecha de la Recolección es requerida',
                        'hour.required' => 'La hora de la Recolección es requerida',
                        ];
            }
            if($this->titleId == 'Entregar'){
            /* Entrega */
                $this->color = 'orange';
                $rules = ['clientId' => 'required',
                        'saleItemId' => 'required',
                        'start' => 'required',
                        'hourId' => 'required',
                        ];
                $messages = ['clientId.required' => 'El Cliente para la Entrega es requerido',
                        'saleItemId.required' => 'El artículo es requerido',
                        'start.required' => 'La fecha de la Recolección es requerida',
                        'hour.required' => 'La hora de la Recolección es requerida',
                        ];
            }
        }
        $this->validate($rules, $messages);
        try{
            $event = Event::find($this->selectedId);
            $event->update(['title' => $this->titleId,
                            'title_note' => $this->titleNote,
                            'desc' => $this->description,
                            'start' => $this->start,
                            'status' => 'Agendado',
                            'color' => $this->color,
                            'payment_method' => $this->paymentMethod,
                            'is_admin_approved' => true,
                            'hour_id' => $this->hourId,
                            'client_id' => $this->clientId,
                            'material_id' => $this->materialId,
                            'item_id' => $this->saleItemId,
                            'weight' => $this->weight,
                            'user_id' => Auth::id(),
                            ]);
            //REFETCH CALENDAR EVENTS AND TOAST
            $this->emit('toast-message', ['msg' => 'Evento Actualizado!', 'icon' =>'success']);
            $this->dispatchBrowserEvent('refetch-events', ['msg' => 'refetch']);
   
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* delete event [listener] */
    public function destroy(){
    /* Delete Event */
        try{
            $item = Event::find($this->selectedId);
            $item->delete($this->selectedId);
        /* Toast - Refetch Events */
            $this->resetPage();
            $this->emit('toast-message', ['msg' => 'Evento Eliminado', 'icon' =>'success']);
            $this->dispatchBrowserEvent('refetch-events', ['msg' => 'refetch']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    public function resetUI(){
        $this->reset(['selectedId', 'formEventOpen', 'eventInfo',
                    'color', 'titleId', 'clientId', 'titleNote', 'materialId', 'paymentMethod',
                    'saleItemId', 'weight', 'address', 'description', 'start', 'hourId', 'status']);
    }
}
