<?php

namespace App\Http\Livewire\Admin\Users;

use App\Models\BranchOffice;
use App\Models\Client;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Hash;
use Laravel\Jetstream\Rules\Role;
use Livewire\Component;
use Livewire\WithPagination;
use Spatie\Permission\Models\Role as ModelsRole;

class UsersIndex extends Component
{
    use WithPagination;

    public $subTitle = 'Listado', $modalTitle = 'USUARIOS', $selectedId,
            $name, $email, $cel, $link, $password, $status, $is_admin, $client_id, $branch_office_id, $role,
            $search, $formOpen;

    public function mount(){
        $this->search = '';
        if($this->selectedId > 0){
            $this->edit(User::find($this->selectedId));
        }
    }

    public function updatingSearch(){
        $this->resetPage();
    }

    /* GET Parameter from URL if exists */
    protected $queryString = ['selectedId'];

    /* Listeners */
    protected $listeners = ['getUser', 'destroy' ];

    public function render()
    {
        $users = User::where('name', 'like', '%'.$this->search.'%')
                        ->orWhere('email', 'like', '%'.$this->search.'%')
                        ->orWhere('cel', 'like', '%'.$this->search.'%')
                        ->paginate(20);
    /* Change is_admin's information */
        foreach($users as $user){
            if($user->is_admin == 1){
                $user->is_admin = 'Administrativo';
            }else{
                $user->is_admin = 'Cliente';
            }
        }
        $clients = Client::where('status', true)->get();
        $branchOffices = BranchOffice::where('status', true)->get();
        $roles = ModelsRole::all();

        return view('livewire.admin.users.users-index', 
                                                    ['items' => $users, 
                                                    'clients' => $clients, 
                                                    'branchOffices' => $branchOffices,
                                                    'roles' => $roles]);
    }

    /* show-form */
    public function showForm(){
    /* Reset Params */
        $this->resetUI();
    /* Open Form */
        $this->formOpen = true;
    }

    /* save new record */
    public function store(){
    /* RULES */
        $rules = ['name' => 'required|min:6',
                'email' => 'required|email',
                'is_admin' => 'required',
                'password' => 'required|min:8',
                ];
        $messages = ['name.required' => 'El nombre es requerido',
                    'name.min' => 'El nombre debe contener al menos 6 caracteres',
                    'email.required' => 'El correo Electronico es requerido',
                    'email.email' => 'El correo electronico debe tener formato de Correo Electronico',
                    'is_admin.required' => 'El tipo de Usuario es requerido',
                    'password.required' => 'La contraseña es requerida',
                    'password.min' => 'La contraseña debe contener al menos 8 caracteres',
                    ];
        $this->validate($rules, $messages);
    /* create record */
        try {
            $newUser = User::create(['name' => $this->name,
                                    'email' => $this->email,
                                    'cel' => $this->cel,
                                    'link' => $this->link,
                                    'password' => Hash::make($this->password),
                                    'is_admin' => $this->is_admin,
                                    'client_id' => $this->client_id,
                                    'branch_office_id' => $this->branch_office_id,
                                    ]);
        /* Assign Role */
            $newUser->assignRole($this->role);
        /* Send email */
            $this->emit('toast-message', ['msg' => 'Usuario registrado!', 'icon' => 'success']);
            
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* Edit show-record */
    public function edit(User $user){
    /* Reset Params */
        $this->resetUI();
    /* Set params */
        $this->selectedId = $user->id; 
        $this->name = $user->name;
        $this->email = $user->email;
        $this->cel = $user->cel;
        $this->link = $user->link;
        $this->status = $user->status;
        $this->is_admin = $user->is_admin;
        $this->client_id = $user->client_id;
        $this->branch_office_id = $user->branch_office_id;
        $this->role = $user->getRoleNames();
    /* Open Form */
        $this->formOpen = true;
    }

    /* update record */
    public function update(){
    /* RULES */
        $rules = ['name' => 'required|min:6',
                    'email' => 'required|email',
                ];
        $messages = ['name.required' => 'El nombre es requerido',
                    'name.min' => 'El nombre debe contener al menos 6 caracteres',
                    'email.required' => 'El correo Electronico es requerido',
                    'email.email' => 'El correo electronico debe tener formato de Correo Electronico',
                    ];
        $this->validate($rules, $messages);
    /* find record */
        $user = User::find($this->selectedId);
    /* update record */
        try{
            $user->update(['name' => $this->name,
                            'email' => $this->email,
                            'cel' => $this->cel,
                            'link' => $this->link,
                            'is_admin' => $this->is_admin,
                            'status' => $this->status,
                            'client_id' => $this->client_id,
                            'branch_office_id' => $this->branch_office_id,
                        ]);
        /* Sync roles */
            $user->syncRoles($this->role);
            $this->emit('toast-message', ['msg' => 'Usuario Actualizado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* delete record [listener] */
    public function destroy(User $user){
        /* VALIDATE later */
        /* if($user->client->count()){
            $this->emit('toast-message', ['msg' => 'La empresea tiene proyectos adjuntos. No puede ser eliminada', 'icon' =>'warning']);
        }else{ */
            try{
                $user->delete($this->selectedId);
                //$this->resetPage();
                $this->emit('toast-message', ['msg' => 'Usuario Eliminado', 'icon' =>'success']);
                
            } catch (Exception $ex) {
                $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
            } 
        
        $this->resetUI();
        return redirect()->route('admin.users.index');
    }

    public function resetUI(){
        $this->reset(['selectedId', 'name', 'email', 'cel', 'link', 'password', 'status', 'is_admin', 'client_id', 'branch_office_id', 'role',
                        'search', 'formOpen']);
    }
}
