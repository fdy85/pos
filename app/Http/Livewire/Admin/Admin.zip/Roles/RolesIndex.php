<?php

namespace App\Http\Livewire\Admin\Roles;

use Exception;
use Illuminate\Support\Arr;
use Livewire\Component;
use Livewire\WithPagination;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesIndex extends Component
{
    use WithPagination;

    public $subTitle = 'Listado', $modalTitle = 'ROLES', $selectedId = 0,
            $name, $rolePermissions=[],
            $search, $formOpen;

    public function mount(){
        $this->search = '';
        $this->formOpen = false;
    }

    public function updatingSearch(){
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy'];

    public function render()
    {
        $items = Role::all();
        $permissions = Permission::pluck('desc', 'id');
        
        return view('livewire.admin.roles.roles-index',['items' => $items, 'permissions' => $permissions]);
    }

    /* show-form */
    public function showForm(){
    /* Reset params */
        $this->resetUI();
    /* Open Form */
        $this->formOpen = true;
    }


    /* Edit show-record */
    public function edit(Role $role){
    /* Reset params */
        $this->resetUI();
    /* Set Params */
        $this->selectedId = $role->id;
    /* get Role's permissions */
        $arrs = $role->permissions;
        foreach($arrs as $arr){
            array_push($this->rolePermissions, $arr->id);
        }
        $this->name = $role->name;
    /* Open Form */
        $this->formOpen = true;  
    }

    /* update record */
    public function update(){
        try{
        /* Update Role */
        /* Find selected Role */
            $role = Role::find($this->selectedId);
        /* Delete current permissions */
            $role->syncPermissions();
        /* Sync selected permissions */
            $role->syncPermissions($this->rolePermissions);
            $this->emit('toast-message', ['msg' => 'Role Actualizado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    public function resetUI(){
        $this->reset(['selectedId', 'name', 'rolePermissions', 'search', 'formOpen']);
    }
}
