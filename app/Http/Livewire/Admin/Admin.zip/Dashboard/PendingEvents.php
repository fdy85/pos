<?php

namespace App\Http\Livewire\Admin\Dashboard;

use App\Models\Cost;
use App\Models\Event;
use App\Models\Folio;
use App\Models\Item;
use App\Models\Material;
use App\Models\Weight;
use Exception;
use Livewire\Component;
use Carbon\Carbon;

class PendingEvents extends Component
{
    public $cost, $totalCost;

    protected $listeners = ['savePayment'];

    public function render()
    {
    /* Filter events excluding grather than today Order DESC */
        $events = Event::whereNotIn('status', ['Finalizado'])
                        ->where('start', '<=', carbon::today()->format('Y-m-d'))
                        ->orderBy('created_at', 'DESC')
                        ->paginate('30');
        return view('livewire.admin.dashboard.pending-events', ['items' => $events]);
    }

    public function saveWeight(Event $event, $weight){
    /* Update Event's weight only for [Recolectar - Entregar] */
        try{
            $event->update(['weight' => $weight]);
            $this->emit('toast-message', ['msg' => 'Peso Registrado', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
    }

    /* Payed event and create folio [Event Id , [true]] */
    public function savePayment(Event $event, $isPayed){
        try{
            if($event->title == 'Nota'){
            /* Finish Event Nota */
                $event->update(['is_payed' => $isPayed,
                                    'status' => 'Finalizado',
                                    'color' => 'blue']);
                $this->emit('toast-message', ['msg' => 'Nota Finalizada', 'icon' =>'success']);
            }else{
            /* Weight Exists */
                if($event->weight > 0){
                /* Finish Event */
                    $event->update(['is_payed' => $isPayed,
                                    'status' => 'Finalizado',
                                    'color' => 'blue'
                                    ]);
                /* [Recolección / Entrega] */
                    if($event->title == 'Recolectar'){
                    /* Recolección */
                        $type = 'Compra';
                    /* Get Cost [from Client or Público en General] */
                        $costPG = Cost::where('client_id', 1)
                                        ->where('costable_id', $event->material_id)
                                        ->where('costable_type', Material::class)
                                        ->first();
                        $cost = Cost::where('client_id', $event->client_id)
                                        ->where('costable_id', $event->material_id)
                                        ->where('costable_type', Material::class)
                                        ->first();          
                    }else{
                    /* Entrega */
                        $type = 'Venta';
                        $costPG = Cost::where('client_id', 1)
                                        ->where('costable_id', $event->item_id)
                                        ->where('costable_type', Item::class)
                                        ->first();
                        $cost = Cost::where('client_id', $event->client_id)
                                        ->where('costable_id', $event->item_id)
                                        ->where('costable_type', Item::class)
                                        ->first();
                    }
                /* Define cost param by Client's Cost or Público en General */
                    if($cost){
                        $this->cost = $cost->cost;
                    }else{
                        $this->cost = $costPG->cost;
                    }
                /* Get total */
                    $this->totalCost = $event->weight * $this->cost;
                /* Create Folio */
                    $newFolio = Folio::create(['folio_type' => $type, 
                                                'capture_type' => 'Calendar',
                                                'total_cost' => $this->totalCost, 
                                                'status' => 1,
                                                'payment_method' => $event->payment_method,
                                                'client_id' => $event->client_id,
                                                'material_id' => $event->material_id,
                                                'item_id' => $event->item_id,
                                                'branch_office_id' => auth()->user()->branch_office_id, 
                                                'user_id' => Auth()->id()
                                            ]);
                /* CREATE WEIGHTS */
                    Weight::create(['weight' => $event->weight, 
                                    'cost' => $this->cost, 
                                    'status' => 1, 
                                    'capture_type' => 'Calendar',
                                    'folio_id' => $newFolio->id, 
                                    'material_id' => $event->material_id, 
                                    'item_id' => $event->item_id, 
                                    'client_id' => $event->client_id, 
                                    'created_by' => Auth()->id()
                                    ]);
                    $this->emit('toast-message', ['msg' => 'Pago Registrado. Folio '.$newFolio->id.' Liberado', 'icon' =>'success']);
                }else{
                /* Only for Donations */
                    if($event->payment_method == 'Donación'){
                    /* Finish Event */
                        $event->update(['is_payed' => $isPayed,
                                        'status' => 'Finalizado',
                                        'color' => 'blue'
                                        ]);
                    /* Create Folio but no records at Weights table */
                        $newFolio = Folio::create(['folio_type' => $event->title == 'Recolectar' ? 'Compra' : 'Venta', 
                                                    'capture_type' => 'Calendar',
                                                    'total_cost' => 0, 
                                                    'status' => 1,
                                                    'payment_method' => $event->payment_method,
                                                    'client_id' => $event->client_id,
                                                    'material_id' => $event->material_id,
                                                    'item_id' => $event->item_id,
                                                    'branch_office_id' => auth()->user()->branch_office_id, 
                                                    'user_id' => Auth()->id()]
                                                );
                        $this->emit('toast-message', ['msg' => 'Pago Registrado. Folio '.$newFolio->id.' Liberado', 'icon' =>'success']);
                    }else{
                    /* Revert Check selection if event has not weight attached */
                        $this->emit('toast-message', ['msg' => 'Complete la información del evento y vuelva a liberar', 'icon' =>'error']);
                        $this->emit('revert-payment', ['id' => 'chk'.$event->id ]);
                    }   
                }
            }
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
    }
}
