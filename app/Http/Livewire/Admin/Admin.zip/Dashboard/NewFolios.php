<?php

namespace App\Http\Livewire\Admin\Dashboard;

use App\Models\Client;
use App\Models\Folio;
use Livewire\Component;
use Livewire\WithPagination;

class NewFolios extends Component
{
    use WithPagination;

    public function render()
    {
        $newFolios = Folio::where('status', false)
                            ->where('capture_type', 'App')
                            ->where('client_id', null)
                            ->paginate('5');
        $clients = Client::where('status', true)->get();
        return view('livewire.admin.dashboard.new-folios', ['items' => $newFolios,
                                                            'clients' => $clients]);
    }
}
