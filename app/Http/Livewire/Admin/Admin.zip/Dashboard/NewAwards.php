<?php

namespace App\Http\Livewire\Admin\Dashboard;

use App\Models\Award;
use Livewire\Component;
use Livewire\WithPagination;

class NewAwards extends Component
{
    use WithPagination;

    public function render()
    {
        $newAwards = Award::where('status', true)->get();
        return view('livewire.admin.dashboard.new-awards', ['items' => $newAwards]);
    }
}
