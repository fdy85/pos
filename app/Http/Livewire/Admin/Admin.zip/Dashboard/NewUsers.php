<?php

namespace App\Http\Livewire\Admin\Dashboard;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;

class NewUsers extends Component
{
    use WithPagination;

    public function render()
    {
        $newUsers = User::where('status', false)->paginate('10');
        return view('livewire.admin.dashboard.new-users', ['items' => $newUsers]);
    }
}
