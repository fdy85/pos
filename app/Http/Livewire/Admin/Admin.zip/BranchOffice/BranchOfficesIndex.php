<?php

namespace App\Http\Livewire\Admin\BranchOffice;

use App\Models\BranchOffice;
use Exception;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;

class BranchOfficesIndex extends Component
{
    use WithPagination;

    public $subTitle = 'Listado', $modalTitle = 'SUCURSALES', $selectedId = 0, 
            $company, $branch_office, $address, $phone, $phone2, $rfc, $status, 
            $search, $formOpen;

    public function mount(){
        $this->search = '';
        $this->formOpen = false;
    }

    public function updatingSearch(){
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy'];

    public function render()
    {
        $items = BranchOffice::where('Branch_office', 'like', '%'.$this->search.'%')
                                ->orWhere('address', 'like', '%'.$this->search.'%')
                                ->orWhere('phone', 'like', '%'.$this->search.'%')
                                ->get();
        return view('livewire.admin.branch-office.branch-offices-index', ['items' => $items]);
    }

    /* show-form */
    public function showForm(){
        $this->resetUI();
        $this->formOpen = true;
    }

    /* save new record */
    public function store(){
        $rules = ['branch_office' => 'required|min:5',
                    'address' => 'required',
                    'phone' => 'required',
                ];
        $messages = ['branch_office.required' => 'El nombre es requerido',
                    'branch_office.min' => 'El nombre debe contener al menos 5 caracteres',
                    'address.required' => 'La dirección es requerida',
                    'phone.required' => 'El alias es requerido',
                    ];
        $this->validate($rules, $messages);

        
        /* create record */
        try {
            $b = BranchOffice::create([
                'branch_office' => $this->branch_office,
                'address' => $this->address,
                'phone' => $this->phone,
                'phone2' => $this->phone2,
                'modified_by' => Auth::id(),
            ]);
            $this->emit('toast-message', ['msg' => 'Sucursal registrada!', 'icon' => 'success']);
            
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* Edit show-record */
    public function edit(BranchOffice $branchOffice){
        $this->formOpen = true;
        $this->selectedId = $branchOffice->id; 
        $this->company = $branchOffice->company;
        $this->branch_office = $branchOffice->branch_office;
        $this->address = $branchOffice->address;
        $this->phone = $branchOffice->phone;
        $this->phone2 = $branchOffice->phone2;
        $this->rfc = $branchOffice->rfc;
        $this->status = $branchOffice->status;
    }

    /* update record */
    public function update(){
        
        $rules = ['branch_office' => 'required|min:5',
                    'address' => 'required',
                    'phone' => 'required',
                ];
        $messages = ['branch_office.required' => 'El nombre es requerido',
                    'branch_office.min' => 'El nombre debe contener al menos 5 caracteres',
                    'address.required' => 'La dirección es requerida',
                    'phone.required' => 'El Teléfono es requerido',
                    ];
        $this->validate($rules, $messages);

        /* update record */
        $branchOffice = BranchOffice::find($this->selectedId);
        try{
            $branchOffice->update([
                'branch_office' => $this->branch_office,
                'address' => $this->address,
                'phone' => $this->phone,
                'phone2' => $this->phone2,
                'modified_by' => Auth::id(),
            ]);
            $this->emit('toast-message', ['msg' => 'Sucursal Actualizada!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* delete record [listener] */
    public function destroy(BranchOffice $branchOffice){
        /* VALIDATE later */
        if($branchOffice->users->count()){
            $this->emit('toast-message', ['msg' => 'La empresea tiene proyectos adjuntos. No puede ser eliminada', 'icon' =>'warning']);
        }else{
            try{
                $branchOffice->delete($this->selectedId);
                //$this->resetPage();
                $this->emit('toast-message', ['msg' => 'Empresa Eliminada', 'icon' =>'success']);
                
            } catch (Exception $ex) {
                $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
            } 
        
        $this->resetUI();
        return redirect()->route('admin.branchoffices.index');
        }
    }

    public function resetUI(){
        $this->reset(['selectedId', 'company', 'branch_office', 'address', 'phone', 'phone2', 'rfc', 'status', 
        'formOpen', 'search']);
    }
}
