<?php

namespace App\Http\Livewire\Admin\BranchOffice;

use App\Models\BranchOffice;
use App\Models\User;
use Livewire\Component;
use Livewire\Livewire;

class BadgeUsers extends Component
{
    public $branchOfficeId;

    public function mount($id){
        $this->branchOfficeId = $id;
    }

    public function render()
    {
        $branchOffice = BranchOffice::find($this->branchOfficeId);
        $users = $branchOffice->users;
        if(!$users->count()){
            $users = collect();
        }
        return view('livewire.admin.branch-office.badge-users', ['users' => $users]);
    }

    public function callUser(User $user){
        return redirect()->to('admin/users?selectedId='.$user->id);
    }
}
