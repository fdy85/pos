<?php

namespace App\Http\Livewire\Admin\Boxcuts;

use App\Models\Boxcut;
use App\Models\Flow;
use App\Models\Folio;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;

class BoxcutsIndex extends Component
{
    use WithPagination;

    /* public params */
    public $subTitle = 'Listado', $modalTitle = 'CORTES DE CAJA', $selectedId, 
            $date, $cashStart, $subTotal, $total, $comments, $status, $branchOfficeId, $boxcutItems,
            $sum = 0, $res = 0,
            $search, $formOpen, $detailsOpen;

    public function mount(){
        $this->selectedId = 0;
        $this->search = '';
        //$this->boxcutItems= collect();
        $this->formOpen = false;
        $this->detailsOpen = false;
    }

    public function updatingSearch(){
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy', 'resetUI', 'newFlow'];
    
    public function render()
    {
        $boxcuts = Boxcut::where('date', 'LIKE', '%'.$this->search.'%')
                        ->where('branch_office_id', auth()->user()->branch_office_id)
                        ->orderBy('id', 'desc')
                        ->paginate(50);

        return view('livewire.admin.boxcuts.boxcuts-index', ['items' => $boxcuts]);
    }

    /* show-form */
    public function showForm(){
    /* Get Open Boxcut */
        $undoneBoxcut = Boxcut::where('status', 0)->first();
    /* Get today Boxcut */
    /* Use Carbon::now('GMT-6') for an exact hour */
        $todayBoxcut = Boxcut::where('date', Carbon::now('GMT-6')->format('d-m-Y'))->first();
        if($undoneBoxcut && $undoneBoxcut->count()){
            $this->emit('toast-message', ['msg' => 'Corte de caja '.$undoneBoxcut->date.' pendiente por liberar' , 'icon' =>'error']);
        }else{
            if($todayBoxcut && $todayBoxcut->count()){
                $todayBoxcut->status 
                    ? $this->emit('toast-message', ['msg' => 'No puede crear cortes de caja con la misma fecha. El corte '.$todayBoxcut->date.' está actualmente cerrado.' , 'icon' =>'error'])
                    : $this->emit('toast-message', ['msg' => 'No puede crear cortes de caja con la misma fecha. El corte '.$todayBoxcut->date.' está actualmente abierto' , 'icon' =>'error']);
            }else{
            /* Set parameters for new boxcut */
                $this->resetUI();
                $this->date = Carbon::now('GMT-6')->format('d-m-Y');
                $this->status = 0;
                $this->formOpen = true;
            }
        }
    }

    /* save new record */
    public function store(){
        $rules = ['date' => 'required',
                'cashStart' => 'required',
                ];
        $messages = ['date.required' => 'El Título es requerido',
                    'cashStart.required' => 'La Apertura de efectivo es requerida',
                    ];
        $this->validate($rules, $messages);
    /* create record */
        try{
            Boxcut::create([
                'date' => $this->date,
                'cash_start' => $this->cashStart,
                'created_by' => Auth::id(),
                'branch_office_id' => auth()->user()->branch_office_id,
            ]);
            $this->emit('toast-message', ['msg' => 'Apertura de caja registrada!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* Edit show-record */
    public function edit(Boxcut $boxcut){
    /* reset params */
        $this->resetUI();
    /* set params */
        $this->selectedId = $boxcut->id; 
        $this->date = $boxcut->date;
        $this->cashStart = $boxcut->cash_start;
        $this->status = $boxcut->status;
    /* open form */
        $this->formOpen = true;
    }

    /* update record */
    public function update(){
        $rules = ['cashStart' => 'required',];
        $messages = ['cashStart.required' => 'La Apertura de efectivo es requerida',];
        $this->validate($rules, $messages);
    /* update record */
        $boxcut = Boxcut::find($this->selectedId);
        try{
            $boxcut->update([
                'cash_start' => $this->cashStart,
                'created_by' => Auth::id(),
            ]);
            $this->emit('toast-message', ['msg' => 'Apertura de Corte Actualizado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI(); 
    }

    /* Boxcut's Details */
    public function details(Boxcut $boxcut){
    /* reset params */
        $this->resetUI();
    /* set params */
        $this->selectedId = $boxcut->id;
        $this->date = $boxcut->date;
        $this->cashStart = $boxcut->cash_start;
        $this->status = $boxcut->status; 
    /* gather Folios and Flows opened by looking for NULL */
        $this->boxcutItems = collect();
        $search = $this->status ? $boxcut->id : NULL;
        $folios = Folio::where('boxcut_id', $search)->get();

        if($folios->count()){
            foreach($folios as $folio){
            /* Add every folio with status = NULL */
                $this->boxcutItems->push(['id' => $folio->id,
                                        'type' =>$folio->folio_type, 
                                        'description' => 'Ticket # '.$folio->id,
                                        'payment_method' => $folio->payment_method,
                                        'qty' => 1,
                                        'cost' => $folio->total_cost,
                                        'total' => $folio->payment_method == 'Efectivo' ? $folio->total_cost : 0,
                                        'created_at' => $folio->created_at,
                                        ]);
            /* sum or rest by detecting payment_method */
                if($folio->payment_method == 'Efectivo'){
                    $folio->folio_type == 'Compra' ? $this->res += $folio->total_cost : $this->sum += $folio->total_cost;
                }
            }
        }
    /* gather Folios and Flows opened by looking for NULL */
        $flows = Flow::where('boxcut_id', $search)->get();
        if($flows->count()){
            foreach($flows as $flow){
            /* Add every Flow with status = NULL */
                $this->boxcutItems->push(['id' => $flow->id,
                                        'type' => $flow->type == 'Inflow' ? 'Entrada' : 'Salida', 
                                        'description' => $flow->description,
                                        'payment_method' => 'Efectivo',
                                        'qty' => $flow->qty,
                                        'cost' => $flow->cost,
                                        'total' => $flow->total,
                                        'created_at' => $flow->created_at,
                                        ]); 
            /* sum or rest by detecting payment_method */
                $flow->type == 'Outflow' ? $this->res += $flow->total : $this->sum += $flow->total;
            }
        }
    /* If boxcut is Closed [true] show boxcut total [field] otherwise do the math */
        $this->total = $boxcut->status ? $boxcut->total : $boxcut->cash_start + $this->sum - $this->res;
    /* open form details */
        $this->detailsOpen = true;
    }

    /* LISTENER NEW FLOW [ID] comes from BoxcutFlows */
    public function newFlow(Flow $flow){
    /* Add this New Flow to BoxcutItems Array */
        $this->boxcutItems->push(['type' => $flow->type == 'Inflow' ? 'Entrada' : 'Salida', 
                                        'description' => $flow->description,
                                        'payment_method' => 'Efectivo',
                                        'qty' => $flow->qty,
                                        'cost' => $flow->cost,
                                        'total' => $flow->total,
                                        'created_at' => $flow->created_at,
                                        ]); 
    /* Sum or rest of Total depending of Flow's TYPE */
        $this->total = ($flow->type == 'Outflow') ? $this->total - $flow->total : $this->total + $flow->total;
    /* Call Reset Params from BoxcutFlows Component */
        $this->emitTo('admin.boxcuts.boxcut-flows', 'resetUI');
    }

    /* Verify / Release Open Boxcut */
    public function verify(Boxcut $boxcut){
        try{
        /* gather Folios and Flows */
            $folios = Folio::where('boxcut_id', NULL)->get();        
            $flows = Flow::where('status', 0)->get();
        /* Add boxcut_id to Folios records */
            foreach($folios as $folio){
                $folio->update(['boxcut_id' => $boxcut->id]);
            }
        /* Add boxcut_id to Flows records */
            foreach($flows as $flow){
                $flow->update(['status' => 1, 'boxcut_id' => $boxcut->id]);
            }
        /* Close current Boxcut */
            $boxcut->update(['status' => 1, 
                            'comments' => $this->comments,
                            'total' => $this->total,
                            'reviewed_by' => auth()->user()->id
            ]);
            $this->emit('toast-message', ['msg' => 'Corte de Caja Verificado Correctamente!', 'icon' =>'success']);
        }catch(Exception $ex){
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* delete record [listener] */
    public function destroy(Boxcut $boxcut){
        if($boxcut->folios->count()){
            $this->emit('toast-message', ['msg' => 'El Corte de Caja tiene Folios relacionados. No puede ser eliminado', 'icon' =>'warning']);
        }else{
            try{
                $boxcut->delete($this->selectedId);
                $this->resetPage();
                $this->emit('toast-message', ['msg' => 'Corte de Caja Eliminado', 'icon' =>'success']);
            } catch (Exception $ex) {
                $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
            }
        }
    }

    /* Resetear variables */
    public function resetUI(){
        $this->reset(['selectedId',
                    'date', 'cashStart', 'subTotal', 'total', 'comments', 'status', 'branchOfficeId', 'boxcutItems',
                    'sum', 'res',
                    'search', 'formOpen', 'detailsOpen']);
    }
}
