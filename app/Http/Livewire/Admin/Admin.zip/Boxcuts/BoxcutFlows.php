<?php

namespace App\Http\Livewire\Admin\Boxcuts;

use App\Models\Boxcut;
use App\Models\Flow;
use Exception;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class BoxcutFlows extends Component
{
    public $boxcut, $type, $description, $qty = 1, $cost, $total;

    public function mount($id){
        $this->boxcut = Boxcut::find($id);
    }
    protected $listeners = ['resetUI'];

    public function render()
    {
        return view('livewire.admin.boxcuts.boxcut-flows');
    }

    /* store new Flow */
    public function store(){
    /* Call Reset params in BoxcutsIndex Component */
        $this->emitTo('admin.boxcuts.boxcut-flows', 'resetUI');
        $rules = ['type' => 'required',
                'description' => 'required',
                'qty' => 'required',
                'cost' => 'required',
                ];
        $messages = ['type.required' => 'El Tipo de Flujo es requerido',
                    'description.required' => 'La descripción es requerida',
                    'qty.required' => 'La Cantidad es requerida',
                    'cost.required' => 'El Valor del Efectivo es requerido',
                    ];
        $this->validate($rules, $messages);
    /* create record */
        try{
            $newFlow = Flow::create([
                                    'type' => $this->type,
                                    'qty' => $this->qty,
                                    'cost' => $this->cost,
                                    'total' => $this->total,
                                    'description' => $this->description,
                                    'created_by' => Auth::id(),
                                    'branch_office_id' => auth()->user()->branch_office_id,
            ]);
        /* After create, Call NewFlow from BoxcutsIndex Component */
            $this->emitTo('admin.boxcuts.boxcuts-index', 'newFlow', $newFlow->id );
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
    }

    public function getTotal(){
    /* Total of New Flow (in view) */
        $this->total = $this->qty * $this->cost;
    }

    public function resetUI(){
        $this->reset(['boxcut', 'type', 'description', 'qty', 'cost', 'total']);
    }
}
