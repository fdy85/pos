<?php

namespace App\Http\Livewire\Admin\Slogans;

use App\Models\Slogan;
use Exception;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;

class SlogansIndex extends Component
{
    use WithPagination;

    /* public params */
    public $subTitle = 'Listado', $modalTitle = 'ESLOGANS', $selectedId, 
            $name, $status,
            $search, $formOpen;

    public function mount(){
        $this->selectedId = 0;
        $this->search = '';
        $this->formOpen = false;
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy'];

    public function render()
    {
        $slogans = Slogan::where('name', 'like', '%'.$this->search.'%')
                        ->where('status', true)
                        ->paginate(20);
        return view('livewire.admin.slogans.slogans-index', ['items' => $slogans]);
    }

    /* show-form */
    public function showForm(){
    /* Reset Params */
        $this->resetUI();
    /* Open Form */
        $this->formOpen = true;
    }

    /* save new record */
    public function store(){
    /* RULES */
        $rules = ['name' => 'required',
                'description' => 'required',
                'cost' => 'required',
                ];
        $messages = ['name.required' => 'El Nombre es requerido',
                    'description.required' => 'La descripción es requerida',
                    'cost.required' => 'El costo a Público en General es requerido',
                    ];
        $this->validate($rules, $messages);
    /* create record */
        try{
            Slogan::create(['name' => $this->name,
                            'modified_by' => Auth::id(),
                            ]);
            $this->emit('toast-message', ['msg' => 'Eslogan registrado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* Edit show-record */
    public function edit(Slogan $slogan){
    /* Reset Params */
        $this->resetUI();
    /* Set params */
        $this->selectedId = $slogan->id; 
        $this->name = $slogan->name;
        $this->status = $slogan->status;
    /* Open Form */
        $this->formOpen = true;
    }

    /* update record */
    public function update(){
    /* RULES */
        $rules = ['name' => 'required|unique:materials,id,{$this->selectedId}'];
        $messages = ['name.required' => 'El nombre es requerido'];
        $this->validate($rules, $messages);
    /* Get slogan info */
        $slogan = Slogan::find($this->selectedId);
        try{
        /* update record */
            $slogan->update(['name' => $this->name,
                            'status' => $this->status,
                            'modified' => Auth::id(),
                            ]);
            $this->emit('toast-message', ['msg' => 'Eslogan Actualizado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* delete record [listener] */
    public function destroy(Slogan $slogan){
        try{
            $slogan->delete($this->selectedId);
            $this->resetPage();
            $this->emit('toast-message', ['msg' => 'Material Eliminado', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
        
    }

    /* Resetear variables */
    public function resetUI(){
        $this->reset(['selectedId', 'name', 'status', 'search', 'formOpen']);
    }
}
