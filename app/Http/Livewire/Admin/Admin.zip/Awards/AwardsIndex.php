<?php

namespace App\Http\Livewire\Admin\Awards;

use App\Models\Award;
use App\Models\Client;
use Exception;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;

class AwardsIndex extends Component
{
    use WithPagination;

    /* public params */
    public $subTitle = 'Listado', $modalTitle = 'PREMIOS', $selectedId, $search;

    public function mount(){
        $this->selectedId = 0;
        $this->search = '';
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy'];

    public function render()
    {
    /* Get all awards but join Material and Client */
        $awards = Award::whereHas('material', function($q){
                                    $q->where('materials.name', 'like', '%'.$this->search.'%');
                                })->orWhereHas('client', function($q){
                                    $q->where('clients.name', 'like', '%'.$this->search.'%');
                                })
                                ->paginate(30);
        return view('livewire.admin.awards.awards-index', ['items' => $awards]);
    }

    /* reset record */
    public function resetAward(Award $award){
        try{
        /* 5000 is the limit */
            if($award->total_weight >= 5000*2){
                $award->update(['total_weight' => $award->total_weight - 5000, 'status' => true]);
            }else{
                $award->update(['total_weight' => $award->total_weight - 5000, 'status' => false]);
            }
            $this->emit('toast-message', ['msg' => 'Registro reseteado', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
    /* Reset params */
        $this->resetUI();
    }

    /* Resetear variables */
    public function resetUI(){
        $this->reset(['selectedId', 'search']);
    }
}
