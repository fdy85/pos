<?php

namespace App\Http\Livewire\Admin\Items;

use App\Models\Cost;
use App\Models\Item;
use Exception;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

use Livewire\Component;

class ItemsIndex extends Component
{
    use WithPagination;

    /* public params */
    public $subTitle = 'Listado', $modalTitle = 'ART. DE VENTA', $selectedId, 
            $name, $description, $status, $cost,
            $search, $formOpen;

    public function mount(){
        $this->selectedId = 0;
        $this->search = '';
        $this->formOpen = false;
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy'];

    public function render()
    {
        $items = Item::where('name', 'like', '%'.$this->search.'%')
                    ->orWhere('description', 'like', '%'.$this->search.'%')
                    ->where('status', true)
                    ->paginate(20);
        return view('livewire.admin.items.items-index', ['items' => $items]);
    }

    /* show-form */
    public function showForm(){
    /* Reset params */
        $this->resetUI();
    /* Show Form */
        $this->formOpen = true;
    }

    /* save new record */
    public function store(){
    /* RULES */
        $rules = ['name' => 'required',
                'description' => 'required',
                'cost' => 'required',
                ];
        $messages = ['name.required' => 'El Nombre es requerido',
                    'description.required' => 'La descripción es requerida',
                    'cost.required' => 'El costo a Público en General es requerido',
                    ];
        $this->validate($rules, $messages);
    /* create NEW ITEM */
        try{
            $item = Item::create(['name' => $this->name,
                                    'description' => $this->description,
                                    'modified_by' => Auth::id(),
                                ]);
        /* Update Cost for Client Público en General */
            $item->costs()->create(['cost' => $this->cost, 'client_id' => 1]);
            $this->emit('toast-message', ['msg' => 'Artículo de Venta registrado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* Edit show-record */
    public function edit(Item $item){
    /* Reset params */
        $this->resetUI();
    /* Get Público en General's cost */
        $c = Cost::where('client_id', 1)
                    ->where('costable_id', $item->id)
                    ->where('costable_type', Item::class)
                    ->first();
    /* Set params */
        $this->selectedId = $item->id; 
        $this->name = $item->name;
        $this->description = $item->description;
        $this->cost = $c->cost;
        $this->status = $item->status;
    /* Open Form */
        $this->formOpen = true;
    }

    /* update record */
    public function update(){
    /* RULES */
        $rules = ['name' => 'required|unique:items,id,{$this->selectedId}',
                    'description.required' => 'La descripción es requerida',
                ];
        $messages = ['name.required' => 'El nombre es requerido',
                    'description.required' => 'La descripción es requerida',
                    ];
        $this->validate($rules, $messages);
    /* find record */
        $item = Item::find($this->selectedId);
        try{
        /* UPDATE record */
            $item->update(['name' => $this->name,
                            'description' => $this->description,
                            'status' => $this->status,
                            'modified' => Auth::id(),
                        ]);
        /* Get Cost for Público en General */
            $c = Cost::where('costable_id', $item->id)
                        ->where('costable_type', Item::class)
                        ->where('client_id', 1)
                        ->first();
        /* UPDATE Cost if different */
            if($this->cost != $c->cost){
                $c->update(['cost' => $this->cost]);
            }
            $this->emit('toast-message', ['msg' => 'Artículo de Venta Actualizado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI(); 
    }

    /* delete record [listener] */
    public function destroy(Item $item){
        if($item->folios->count()){
            $this->emit('toast-message', ['msg' => 'Artículo de Venta tiene Folios relacionados. No puede ser eliminado', 'icon' =>'warning']);
        }else{
            try{
                $item->delete($this->selectedId);
                $this->resetPage();
                $this->emit('toast-message', ['msg' => 'Artículo de Venta Eliminado', 'icon' =>'success']);
            } catch (Exception $ex) {
                $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
            }
            $this->resetUI();
        }
    }

    /* Resetear variables */
    public function resetUI(){
        $this->reset(['selectedId',
                    'name', 'description', 'status', 'cost',
                    'search', 'formOpen']);
    }
}
