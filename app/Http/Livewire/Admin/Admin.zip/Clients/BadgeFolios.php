<?php

namespace App\Http\Livewire\Admin\Clients;

use App\Models\Client;
use App\Models\Folio;
use Livewire\Component;

class BadgeFolios extends Component
{
    public $clientId;

    public function mount($id){
    /* set ClientId */
        $this->clientId = $id;
    }

    public function render()
    {
    /* Get Client */
        $client = Client::find($this->clientId);
    /* If not exist any folios, set as Null */
        $folios = $client->folios->count() ?  $client->folios : $folios = collect();

        return view('livewire.admin.clients.badge-folios', ['folios' => $folios]);
    }

    public function callFolio(Folio $folio){
    /* Redirect to Folios with Query String [?selectedId=] in order to see a specific Folio */
        return redirect()->to('admin/folios?selectedId='.$folio->id);
    }
}
