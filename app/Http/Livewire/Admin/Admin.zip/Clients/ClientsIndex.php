<?php

namespace App\Http\Livewire\Admin\Clients;

use App\Models\Client;
use App\Models\Cost;
use App\Models\Historical;
use App\Models\Item;
use App\Models\Material;
use Exception;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;

class ClientsIndex extends Component
{
    use WithPagination;

    /* public params */
    public $subTitle = 'Listado', $modalTitle = 'CLIENTES', $selectedId, 
            $name, $alias, $contact, $address, $email, $cel, $cel2, $rfc, $status, 
            $clientMaterials = [], $newClientMaterials = [], $clientSaleItems = [], $newClientSaleItems = [], 
            $historicalMaterials, $historicalSaleItems,
            $search, $formOpen;

    public function mount(){
        $this->selectedId = 0;
        $this->search = '';
        $this->formOpen = false;
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    /* Listeners */
    protected $listeners = ['destroy'];

    public function render()
    {
        $clients = Client::where('name', 'like', '%'.$this->search.'%')
                    ->orWhere('email', 'like', '%'.$this->search.'%')
                    ->orWhere('cel', 'like', '%'.$this->search.'%')
                    ->orWhere('contact', 'like', '%'.$this->search.'%')
                    ->paginate(20);
        $materials = Material::where('status', true)->get();
        $saleItems = Item::where('status', true)->get();

        return view('livewire.admin.clients.clients-index', [
                                                            'items' => $clients,
                                                            'materials' => $materials,
                                                            'saleItems' => $saleItems
                                                            ]);
    }

    /* show-form */
    public function showForm(){
    /* Reset Params */
        $this->resetUI();
    /* Open Form */
        $this->formOpen = true;
    }

    /* save new record */
    public function store(){
        $rules = ['name' => 'required',
                'alias' => 'required',
                'contact' => 'required',
                ];
        $messages = ['name.required' => 'El Nombre es requerido',
                    'alias.required' => 'El Alias es requerido',
                    'contact.required' => 'El Alias es requerido',
                    ];
        $this->validate($rules, $messages);
    /* create record */
        try{
            $client = Client::create(['name' => $this->name,
                                        'alias' => $this->alias,
                                        'contact' => $this->contact,
                                        'address' => $this->address,
                                        'email' => $this->email,
                                        'rfc' => $this->rfc,
                                        'cel' => $this->cel,
                                        'cel2' => $this->cel2,
                                        'modified_by' => Auth::id(),
                                    ]);
        /* If user sets specific cost for any Material */
            if(count($this->clientMaterials)){
                foreach(Material::where('status', true)->get() as $item){
                    foreach($this->clientMaterials as $key => $value){
                        if($item->id == $key AND $value > 0){
                            $item->costs()->create(['cost' => $value, 'client_id' => $client->id]);
                        }
                    }
                }
            }
        /* If user sets specific cost for any Item */
            if(count($this->clientSaleItems)){
                foreach(Item::where('status', true)->get() as $item){
                    foreach($this->clientSaleItems as $key => $value){
                        if($item->id == $key AND $value > 0){
                            $item->costs()->create(['cost' => $value, 'client_id' => $client->id]);
                        }
                    }
                }
            }
            $this->emit('toast-message', ['msg' => 'Cliente registrado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* Edit show-record */
    public function edit(Client $client){
    /* reset params */
        $this->resetUI();
    /* set params */
        $this->selectedId = $client->id; 
        $this->name = $client->name;
        $this->alias = $client->alias;
        $this->contact = $client->contact;
        $this->address = $client->address;
        $this->email = $client->email;
        $this->rfc = $client->rfc;
        $this->cel = $client->cel;
        $this->cel2 = $client->cel2;
        $this->status = $client->status;
    /* Gather information of Material's costs */
        foreach(Material::where('status', true)->get() as $material){
            foreach($material->costs as $cost){
                if($cost->client_id == $this->selectedId && $cost->costable_type == 'App\Models\Material'){
                    $this->clientMaterials+=[$cost->costable_id => $cost->cost];
                }
            }
        }
    /* Gather information of Item's costs */
        foreach(Item::where('status', true)->get() as $saleItem){
            foreach($saleItem->costs as $cost){
                if($cost->client_id == $this->selectedId && $cost->costable_type == 'App\Models\Item'){
                    $this->clientSaleItems+= [$cost->costable_id => $cost->cost];
                }
            }
        }
    /* Gather information for Material's Historicals */
        $this->historicalMaterials = Historical::where('client_id', $this->selectedId)
                                                ->where('model', Material::class)
                                                ->orderBy('name')
                                                ->get();
    /* Gather information for Item's Historicals */
        $this->historicalSaleItems = Historical::where('client_id', $this->selectedId)
                                                ->where('model', Item::class)
                                                ->orderBy('name')
                                                ->get();
    /* Open Form */
        $this->formOpen = true;
    }

    /* update record */
    public function update(){
    /* RULES */
        $rules = ['name' => 'required|unique:clients,id,{$this->selectedId}'];
        $messages = ['name.required' => 'El nombre es requerido'];
        $this->validate($rules, $messages);
    /* update record */
    /* Get current Client */
        $client = Client::find($this->selectedId);
        try{
            $client->update(['name' => $this->name,
                            'alias' => $this->alias,
                            'contact' => $this->contact,
                            'address' => $this->address,
                            'email' => $this->email,
                            'rfc' => $this->rfc,
                            'cel' => $this->cel,
                            'cel2' => $this->cel2,
                            'status' => $this->status,
                            'modified' => Auth::id(),
                            ]);
        /* Update Material's cost information */
            if(count($this->clientMaterials)){
                foreach($this->clientMaterials as $key => $value){
                /* Gather last cost Information */
                    $lastMaterialCost = Cost::where('costable_id', $key)
                                    ->where('costable_type', Material::class)
                                    ->where('client_id', $this->selectedId)->first();
                /* Evaluates if different */
                    if($lastMaterialCost->cost != floatval($value)){
                        $tempMaterial = Material::find($key);
                    /* set to number if empty */
                        if($value == ""){
                            $value = 0.0;
                        }
                    /* create new Historical */
                        Historical::create(['name' => $tempMaterial->name,
                                            'from' => $lastMaterialCost->created_at,
                                            'cost' => $lastMaterialCost->cost,
                                            'client_id' => $client->id,
                                            'key' => $lastMaterialCost->costable_id,
                                            'model' => $lastMaterialCost->costable_type
                                            ]); 
                    /* update current cost */
                        $lastMaterialCost->update(['cost' => $value]);
                    }
                }
            }
        /* If cost is new */
            if(count($this->newClientMaterials)){
            /* Evaluate against all active materials */
                foreach(Material::where('status', true)->get() as $material){
                    foreach($this->newClientMaterials as $key => $value){
                        if($material->id == $key){
                            if($value != null AND $value > 0){ 
                                /* create new Cost */
                                    $material->costs()->create(['cost' => $value, 'client_id' => $client->id]); 
                            }
                        }
                    }
                }
            }

        /* Update Item's cost information */
            if(count($this->clientSaleItems)){
                foreach($this->clientSaleItems as $key => $value){
                /* Gather last cost Information */
                    $lastSaleItemCost = Cost::where('costable_id', $key)
                                            ->where('costable_type', Item::class)
                                            ->where('client_id', $this->selectedId)->first();
                /* Evaluates if different */
                    if($lastSaleItemCost->cost != floatval($value)){
                        $tempMaterial = Item::find($key);
                    /* set to number if empty */
                        if($value == ""){
                            $value = 0.0;
                        }
                    /* create new Historical */
                        Historical::create(['name' => $tempMaterial->name,
                                            'cost' => $lastSaleItemCost->cost,
                                            'client_id' => $client->id,
                                            'key' => $lastSaleItemCost->costable_id,
                                            'model' => $lastSaleItemCost->costable_type
                                            ]);
                    /* update current cost */
                        $lastSaleItemCost->update(['cost' => $value]);
                    }
                }
            }
        /* If cost is new */
            if(count($this->newClientSaleItems)){
            /* Evaluate against all active Items */
                foreach(Item::where('status', true)->get() as $saleItems){
                    foreach($this->newClientSaleItems as $key => $value){
                        if($saleItems->id == $key){
                            if($value != null AND $value > 0){ 
                                /* create new Cost */
                                    $saleItems->costs()->create(['cost' => $value, 'client_id' => $client->id]); 
                            }
                        }
                    }
                }
            }

            $this->emit('toast-message', ['msg' => 'Cliente Actualizado!', 'icon' =>'success']);
        } catch (Exception $ex) {
            $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
        }
        $this->resetUI();
    }

    /* delete record [listener] */
    public function destroy(Client $client){
        if($client->folios->count()){
            $this->emit('toast-message', ['msg' => 'El Cliente tiene Folios relacionados. No puede ser eliminado', 'icon' =>'warning']);
        }else{
            try{
                $client->delete($this->selectedId);
                $this->resetPage();
                $this->emit('toast-message', ['msg' => 'Cliente Eliminado', 'icon' =>'success']);
            } catch (Exception $ex) {
                $this->emit('toast-message', ['msg' => $ex->getMessage(), 'icon' => 'error']);
            }
            $this->resetUI();
        }
    }

    /* Resetear variables */
    public function resetUI(){
        $this->reset(['selectedId',
                    'name', 'alias', 'contact', 'address', 'email', 'cel', 'cel2', 'rfc', 'status', 
                    'clientMaterials', 'clientSaleItems', 'newClientMaterials' , 'newClientSaleItems', 
                    'historicalMaterials', 'historicalSaleItems',
                    'search', 'formOpen']);
    }
}
